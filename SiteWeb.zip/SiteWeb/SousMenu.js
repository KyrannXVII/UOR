
var Phy = document.getElementById("Phy"); //sous menu physique
var Maths = document.getElementById("Maths");//sous menu maths
var Bio = document.getElementById("Bio"); //sous menu biologie

 //si on clique autre par que sur les boutons des sous menus, cela cache les sous menus.
window.onclick= function(event){ //on ne devrais pas utiliser a-menu car ca se refere a tout les bouton de la barre de navigation, et non pas juste au bouton de sous menu
	if (!event.target.matches('.a-menu')) {//mais les autres boutons envoient sur d'autre page donc au final pas besoin de cacher les sous menu quand on part de la page
		Phy.style.display ="none";
		Maths.style.display ="none";
		Bio.style.display ="none";
	
}}

function SousMenuPhy(){ 

	if(getComputedStyle(Phy).display !="none"){ //Récupère la valeur du display, si display est visible alors on le cache    https://mareconversionpro.fr/modifier-css-javascript/ https://yard.onl/sitelycee/cours/js/_Js.html?RcuprerlespropritsCSS.html
		Phy.style.display ="none";				//alors on le cache (permet que lorsque l'on reclique sur le bouton cela cache le menu)
	} else{										//sinon montre phy mais cache bien maths et bio  source : https://www.journaldunet.fr/web-tech/developpement/1202637-comment-afficher-masquer-une-div-en-javascript/
		Phy.style.display ="block";
		Maths.style.display ="none";
		Bio.style.display ="none";
	}}

function SousMenuMaths(){

	if(getComputedStyle(Maths).display !="none"){
		Maths.style.display ="none";
	} else{
		Maths.style.display ="block";
		Bio.style.display ="none";
		Phy.style.display ="none";
	}}

function SousMenuBio(){
	
	if(getComputedStyle(Bio).display !="none"){
		Bio.style.display ="none";
	} else{
		Bio.style.display ="block";
		Maths.style.display ="none";
		Phy.style.display ="none";
	}}
//esquisse d'une "meilleure" soluce
/*function SousMenu(Matiere){
    var matiere = document.getElementById(Matiere);
    if(getComputedStyle(matiere).display !="none"){
		matiere.style.display ="none";
	} else{
		matiere.style.display ="block";
}*/