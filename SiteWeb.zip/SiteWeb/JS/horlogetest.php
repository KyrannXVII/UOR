<!DOCTYPE html>
<html>

<head profile="http://dublincore.org/documents/2008/08/04/dc-html/">
    <link rel="stylesheet" href="Horloge.css">
    <meta charset="utf-8">
	
</head>


<body>

                <nav class="menu-navi">
                
                        <table>
                            <tr>
                                <td class="bouton"><a class="a-menu" href="../index.php">Accueil</a></td>
        
                                <?php //Permet de modifier le bouton celon la connection ou non du l'utilisateur
                                    if(!empty($_SESSION['Prénom'])){
                                        echo 	'<td class="bouton">'.'<a class="a-menu" href="../utilisateur.php">'.$_SESSION['Prénom']." ".$_SESSION['Nom'].' </a></td>';}
                                    else echo 	'<td class="bouton">'.'<a class="a-menu" href="../connexion.php">'."Connexion".' </a></td>'
                                ?>
                                
                                <td class="bouton"><a class="a-menu" href="/JS/horlogetest.php"> Horloge Relative </a></td>  
                            </tr>
                        </table>
                    </nav>
                    
<div class=horloge>> 
       <div class = heure></div>
       <div class = minute></div>
       <div class = seconde></div>
       <H2>Horloge représentant le temps actuel (Dans le vaisseau)</H2>
  </div> 

  <div class=horlogeR>> 
        <div class = heureR></div>
        <div class = minuteR></div>
        <div class = secondeR></div>
        <H2>Horloge représentant la dilatation du temps selon la vitesse choisis (Horloge terre vu par vaisseau)</H2>
        <input type = "button" value="changer de vitesse" id="ChangeVit" >
  </div> 
  

 

   <script> //animation JS    ----> http://villemin.gerard.free.fr/Science/Reltemps.htm 
    //Var pour calcul temps relatif
    var c = 300000000; //vitesse de la lumiere arrondi(m/s)
    var VitUtili = parseInt(prompt("Choisis une vitesse entre 1ms et 300000000ms",'tape le ici',maxlength='10'));
    var bouton =document.getElementById("ChangeVit");
    bouton.onclick = function(){ document.location.reload(true);};//pour changer de vitesse on relance la page 
    var rV = VitUtili/c; //rapport des vitesse
    var rD = 1/Math.sqrt(1-(rV*rV)); //rapport des durée
    var ticHorloge = (1/rD)*1000; // 1seconde horloge terre vu par vaisseau = (1seconde vaisseau /rD)* 1000 pour mettre en ms 



    //heure local pour avoir l'horloge initialiser sur l'heure de l'acces a la page
     var date = new Date;
    var secondeLocal = date.getSeconds();
    var minuteLocal = date.getMinutes();
    var heureLocal = date.getHours();
    //recupéré les div heure/minute/seconde*/ 
    //Témoin
    var heure =  document.querySelector('.heure'); // problématique : comment récupérer un selecteur CSS pour pouvoir y inscrire quelque chose :https://developer.mozilla.org/fr/docs/Web/API/Document/querySelector 
    var minute = document.querySelector('.minute');
    var seconde = document.querySelector('.seconde');
    //Relative
    var heureR = document.querySelector('.heureR'); 
    var minuteR = document.querySelector('.minuteR');
    var secondeR = document.querySelector('.secondeR');
    //Changement de vitesse
    

    //angle de depart des aiguilles baser sur l'heure qu'il est, comvertie en degres pour la rotation des aiguille ce sont les mêmes pour les deux 
    var sec = secondeLocal * 6; //1s = 6° de l'horloge
    var min = minuteLocal * 6;
    var heu = heureLocal * 30;
    heure.style.webkitTransform = 'rotate('+heu+'deg)'; //webkit pour compatibilité : https://cssanimation.rocks/fr/clocks/ -> écrit dans le selecteur rotate(....) https://qastack.fr/programming/708895/how-to-set-the-style-webkit-transform-dynamically-using-javascript
    minute.style.webkitTransform = 'rotate('+min+'deg)';
    seconde.style.webkitTransform = 'rotate('+sec+'deg)';
    
    var secR = secondeLocal * 6; //1s = 6° de l'horloge
    var minR = minuteLocal * 6;
    var heuR = heureLocal * 30;
    heureR.style.webkitTransform = 'rotate('+heuR+'deg)';
    minuteR.style.webkitTransform = 'rotate('+minR+'deg)';
    secondeR.style.webkitTransform = 'rotate('+secR+'deg)';

    /* sec,min,heu,secR,minR,heuR = angles */





  /* mauvaise methode 
    setInterval(function(){ //setInterval = repete tout les x fois une fonction
        
        heure.style.webkitTransform = 'rotate('+heu+'deg)';
        heu+=30 ; },3600000 ); // toute les heures (60*60*1000 milisecondes)

    
   /* setInterval(function(){ //premier essaie en prenant le probleme du point de vue du temps mais avec 60k l'aiguille ne bougeais pas

        minute.style.webkitTransform = 'rotate('+min+'deg)';
        min+=6 ; },60000); // toute les minute (60*1000 milisecondes) l'angle augmente de 6° (360°/60)
*/
//Horloge témoin
    setInterval(function(){ //https://www.xul.fr/ecmascript/settimeout.php -> recherche : commenter repeter une fonction tout les x temps 

        sec+=6; // on tourne de 6°
        //toute les secondes tourne l'aiguille de 6° de +, si les degres de l'aiguille seconde est multiple de 366 alors 6°+ sur aiguille minute pareil pour heure avec minute 
        seconde.style.webkitTransform = 'rotate('+sec+'deg)'; // https://openclassrooms.com/forum/sujet/comment-faire-tourner-une-image-a-l-infini-en-js --> tourner un item en js
       
            if ((sec%366) == 0 ){   // si les secondes sont un multiple de 366 (1 tour d'horloge completer donc 60sec passé donc 1minute, mais + 1s pour passer a la minute suivante) 
            min+=6; 
            minute.style.webkitTransform = 'rotate('+min+'deg)';
                if((min%366)== 0){  //de meme que pour les minutes
                heu+=30 ;
                heure.style.webkitTransform = 'rotate('+heu+'deg)';}
            }
        },1000); // toute les seconde (1000 milisecondes), l'angle augmente de 6°

//Horloge Relative
    setInterval(function(){
        secR+=6;
        secondeR.style.webkitTransform = 'rotate('+secR+'deg)';
       
            if ((secR%366) == 0 ){
            minR+=6; 
            minuteR.style.webkitTransform = 'rotate('+minR+'deg)';
                if((minR%366)== 0){
                heuR+=30 ;
                heureR.style.webkitTransform = 'rotate('+heuR+'deg)';}
            }
        },ticHorloge); //pas toute les secondes mais les "secondes relative"

   </script>
</body>



</html>