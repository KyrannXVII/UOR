<?php //Permet de garder les variables de l'utilisateur en mémoire, autres méthode possible: cookie

session_start();

?>
<!DOCTYPE html>
<html>

<head profile="http://dublincore.org/documents/2008/08/04/dc-html/">
	<title>L'Histoire de Newton en bref </title>
	<meta charset="utf-8">

	<link rel="stylesheet" href="stylelsmlm.css">
	
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" />
	
	<meta name="DC.Title" lang="fr" content="L'Histoire de Newton en bref ">
	<meta name="DC.Subjetc" lang="fr" content="isaac Newton, Newton, l'histoire de Newton">
	<meta name="DC.Description" lang="fr" 
		content="L'histoire d'Isaac Newton en bref, accessible à toutes et à tous.">
	<meta name="DC.Language" scheme="DCTERMS.RFC4646" content="fr-FR">
</head>

<body>
<nav class="menu-navi">
		
		<table>
			<tr>
				<td class="bouton"><a class="a-menu" href="index.php">Accueil</a></td>
				<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuPhy()"> Physique
					<div id ="Phy" class="test">
						<a  class='a-sousMenu' href="Hawking.php"> Stephen Hawking </a> 
						<a  class='a-sousMenu' href="Einstein.php"> Albert Einstein </a> 
						<a  class='a-sousMenu' href="Newton.php"> Isaac Newton </a> 
					</div>	
				</td>   
				<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuMaths()"> Mathématique
					<div id ="Maths" class="test">
						<a  class='a-sousMenu' href="#"> Maths1 </a> 
						<a  class='a-sousMenu' href="#"> Maths2 </a> 
						<a  class='a-sousMenu' href="#"> Maths3 </a> 
					</div>	
				</td>
				<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuBio()"> Biologie
					<div id ="Bio" class="test">
						<a  class='a-sousMenu' href="#"> Charles Darwin </a> 
						<a  class='a-sousMenu' href="#"> Bio2</a> 
						<a  class='a-sousMenu' href="#"> Bio3 </a> 
					</div>	
				</td>

				<td class="bouton"><a class="a-menu" href="Source.php"> Les Sources </a></td>
				
			

				<?php //Permet de modifier le bouton celon la connection ou non du l'utilisateur
					if(!empty($_SESSION['Prénom'])){
						echo 	'<td class="bouton">'.'<a class="a-menu" href="utilisateur.php">'.$_SESSION['Prénom']." ".$_SESSION['Nom'].' </a></td>';}
					else echo 	'<td class="bouton">'.'<a class="a-menu" href="connexion.php">'."Connexion".' </a></td>'
				?>
				<td class="bouton"><a class="a-menu" href="/JS/horlogetest.php"> Horloge Relative </a></td>
				
			</tr>
		</table>
	</nav>

<h1>La page réservé à Newton est en cours d'écriture soyez patient.</h1>

<p style="text-align:center"><img src="https://media.giphy.com/media/IoP0PvbbSWGAM/giphy.gif" alt="another gif Work" height="400" width="450"></p>
<script type="text/javascript" src="SousMenu.js"></script>

</body>

</html>