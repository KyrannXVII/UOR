<?php //Permet de garder les variables de l'utilisateur en mémoire, autres méthode possible: cookie

session_start();

?>
<!DOCTYPE html>
<html>

<head profile="http://dublincore.org/documents/2008/08/04/dc-html/">

	<title>L'Histoire de Hawking en bref </title>
	<meta charset="utf-8">

	<link rel="stylesheet" href="stylelsmlm.css">

	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" />

	<meta name="DC.Title" lang="fr" content="L'Histoire de Hawking en bref ">
	<meta name="DC.Subjetc" lang="fr" content="Stephen Hawking, Hawking, l'histoire de Hawking">
	<meta name="DC.Description" lang="fr"
		content="L'histoire de Stephen Hawking en bref, accessible à toutes et à tous.">
	<meta name="DC.Language" scheme="DCTERMS.RFC4646" content="fr-FR">
</head>

<body>
<nav class="menu-navi">
		
		<table>
			<tr>
				<td class="bouton"><a class="a-menu" href="index.php">Accueil</a></td>
				<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuPhy()"> Physique
					<div id ="Phy" class="test">
						<a  class='a-sousMenu' href="Hawking.php"> Stephen Hawking </a> 
						<a  class='a-sousMenu' href="Einstein.php"> Albert Einstein </a> 
						<a  class='a-sousMenu' href="Newton.php"> Isaac Newton </a> 
					</div>	
				</td>   
				<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuMaths()"> Mathématique
					<div id ="Maths" class="test">
						<a  class='a-sousMenu' href="#"> Maths1 </a> 
						<a  class='a-sousMenu' href="#"> Maths2 </a> 
						<a  class='a-sousMenu' href="#"> Maths3 </a> 
					</div>	
				</td>
				<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuBio()"> Biologie
					<div id ="Bio" class="test">
						<a  class='a-sousMenu' href="#"> Charles Darwin </a> 
						<a  class='a-sousMenu' href="#"> Bio2</a> 
						<a  class='a-sousMenu' href="#"> Bio3 </a> 
					</div>	
				</td>

				<td class="bouton"><a class="a-menu" href="Source.php"> Les Sources </a></td>
				
			

				<?php //Permet de modifier le bouton celon la connection ou non du l'utilisateur
					if(!empty($_SESSION['Prénom'])){
						echo 	'<td class="bouton">'.'<a class="a-menu" href="utilisateur.php">'.$_SESSION['Prénom']." ".$_SESSION['Nom'].' </a></td>';}
					else echo 	'<td class="bouton">'.'<a class="a-menu" href="connexion.php">'."Connexion".' </a></td>'
				?>
				<td class="bouton"><a class="a-menu" href="/JS/horlogetest.php"> Horloge Relative </a></td>
				
			</tr>
		</table>
	</nav>




<div class="txt">
	<h2 style="text-decoration: underline">Stephen Hawking </h2>


	<img class="img1" src="Images/Hawking.jpg" alt="Portrait de Stephen Hawking">
	<p>Stephen Hawking a révolutionné la cosmologie. Pour les plus neophytes d'entre nous la cosmologie est une branche
		de l'astrophysique,
		qui a comme but d'étudié l'Univers dans son ensembles. Par exemple la théorie du BigBang fait partie de la
		cosmologie.
		Stephen hawking révolutionna la cosmologie de par ces recherches sur les trous noirs et leur rayonnement (mais
		pas
		que voila un petit top des
		<a href=https://www.futura-sciences.com/sciences/actualites/physique-stephen-hawking-top-5-decouvertes-70508/
			target="_blank">
			théories de Hawking </a>)
		(et oui un trou noir n'est pas qu'un corps physique qui "absorbe" la lumière, il emet un rayonnement). Ces même
		rayonnement qui son nommé maintenant
		<a href=https://www.futura-sciences.com/sciences/definitions/astronomie-rayonnement-hawking-4889/
			target="_blank">
			"Rayonnement d'Hawking"</a> .
		Hawking est certainement la personne qui connaissait le mieux les trous noir.
		Evidement il n'a pas fait "que" cela mais nous ne sommes pas ici pour énumerer ses nombreux traveaux mais plus
		pour
		en apprendre un peu plus sur lui.
	</p>
  


	<h3 class="stopf">Hawking, l'Einstein paresseux</h3>
	<div class="div1">
		<p>
			Ce surnom de Einstein paresseux n'est pas de moi mais des amis de sa jeunesse. Il n'étais pas studieux à
			l'école,
			mais ses professeurs sentaient que hawking était plus intelligent que la moyenne.
			Depuis son plus jeune âge hawking developpa sa passion pour les sciences en lisant d'innombrable ouvrages.
			Sachant
			que de ses 15 ans à ses 16 ans le jeune Hawking construisa avec ses amis un ordinateurs
			appelé LUCE pour Logical Uniselector Computing Engine. Ce qui est assez fou qui de nos jours peut dire : "Oui à
			16
			ans j'ai construit avec mes amis un ordinateur de A à Z".
		</p>
	</div>

	<div class="div2">
		<p>
			Par la suite il passa ses années universitaire à Oxford étudiant la physique. D'après lui, il n'aurais travaillé
			qu'un millier d'heures, c'est à dire qu'une heure par jour pendant ses trois années de licence.
			Un autre exmple montrant qu'il était hors norme, lors de sa licence, il avais, avec ses amis, un devoir de 13
			problèmes de physique extrêment complexe. Ses amis ont travaillé dessus des jours entiers et n'on réussi
			qu'en finir 2. Hawking par manque de sérieux n'a commencé à les faires que le matin même de la date final. De ce
			fait
			il n'a eu que 3 heures pour faire le devoir, les 3 heures écoulés, il alla pret de ses
			amis leur annonçant la mauvaise nouvelle... Il n'avait eu le temps que pour 10 exercices.
		</p>
	</div>
	
	<h3 class="stopf">Le Drame... </h3>
	<p>Lors de ses années universitaires Stephen Hawnking commença à devenir de plus en plus maladroit dans ses
		mouvements. Son père s'inquiétant l'emmena à l'hopital. Il fît des examens neurologique
		et les médecins lui ont diagnostiqué la SLA appelé en France la maladie de Charcot. La SLA est une affection
		incurable, produisant une dégénérescence de la moelle épinière et des cellules nerveuses
		dirigient l'activité musculaire volontaire. Si vous désirez en savoir plus sur la SLA <a
			href="https://www.arsla.org/la-sla-cest-quoi/">ce site</a> permet de mieux comprendre le phénomène.
		Cette maladie entraine le plus souvent la mort du patient par suffocation. Lorsque Hawking fût diagnostiqué
		atteint de la SLA ce fût un coup extrèmement dur, mais il avait aussi rencontré la personne qui allait partager
		un très long moment de sa vie, Jane Wilde sa futur femme et mère de ses enfants.
		Ce qui lui a permis d'avancer et de faire finir son doctorat. Si vous avez du temps à consacré à l'histoire de Mr Hawking 
		je vous conseille alors de regarder le <a href="https://www.youtube.com/watch?v=gzbRSCxqTyw">film documentaire</a> qu'ARTE à produit

	</p>
	

	<h3>... Pas si dramatique </h3>
	<p> Il peut être choquant de dire que l'handicap d'Hawking ne fût pas si malheureux, dramatique, "noir" car biensûr
		il en a souffert
		et c'était loin d'être facile tout les jours. Cependant cela lui à permis de devenir ce grand homme de science.
		Ca maladie ne lui permettant
		pas d'écrire des équations, il a dû s'adapter pour résoudre des équations extrêment complexe seulement de tête.
		Et la vision qu'il avait de son environement, des mathématiques et de la physique
		lui à permis de penser différement de ses confrère. Quand comme tout chercheur il avait eu une idée, une piste
		de recherche, une révélation pendant une nuit, lui ne pouvait pas se lever pour aller la noté
		et aller se recoucher. Alors il ne s'endormais pas et réfléchissait toute la nuit sur sa piste. Comme il
		arrivait à visualiser les équations, les schémas, il arrivait à avancer lors de ses nuits blanches.
	</p>

	<h3>A brief history of time</h3>
	<p> Faisons un bon dans le temps jusqu'en 1980. Stephen Hawking est devenu une grande figure universitaire, reconnu
		ses pairs, avec un poste lui permettant de travailler malgrès son handicap.
		Cependant avec les frais des soins et il fait qu'il fallais commencer a payer les Études de sa fille Lucy, il
		entreprie son nouveau défi, écrire un livre de vulgarisation
		scientifique expliquant les origines et le futur de l'Univers ainsi que des principe complexe de la science tel
		que l'entropie d'un gaz ou encore la gravitation quantique.
		Ce livre se devait d'être accessible aux plus grands nombres et non pas pour les hautes sphères scientifiques.
		Et "A brief history of time" (Une brève histoire du Temps) fût un best-seller.
		Son best-seller lui à permis de se faire connaitre du grand public.
	</p>

	<h3>Une icône scientifique </h3>
	<p>Stephen Hawking fût récompensé d'un très grand nombre de médaille tel que la Médaille Hughes de la royal society
		ou le prix Albert Einstein Award et bien d'autre encore. Il fût aussi professeur Lucasien, un très grand titre.
		Ou seul quelque scientifique l'ont été, tel que Newton.
		Dans le domaine scientifique il fût un géant, mais aussi dans le domaine du public, tel qu'exliqué plus haut,
		grâce a son best-seller. Il est devenu une figure culturelle,
		il a jouais son propre rôle dans par exemple un épisode de <em>Star Trek : The Next Generation</em>, et est
		intervenu plusieurs fois dans la série <em>The Big Bang Theory</em>,
		dans <em>Les Simpson</em> et il a continué à écrire ou coécrire des livre de vulgarisation scientifique, mais
		aussi des livres pour enfants avec sa fille lucy.
	</p>
</div>
<script type="text/javascript" src="SousMenu.js"></script>

</body>

</html>

