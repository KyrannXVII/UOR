<?php //Permet de garder les variables de l'utilisateur en mémoire, autres méthode possible: cookie

session_start();

?>
<!DOCTYPE html>
<html>

<head profile="http://dublincore.org/documents/2008/08/04/dc-html/">
	<title>Les sources utilisées | Scientifiques marquant le monde</title>
	<meta charset="utf-8">
	
	<link rel="stylesheet" href="stylelsmlm.css">

	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" />
	
	<meta name="DC.Title" lang="fr" content="Les sources utilisées | Scientifiques marquant le monde">
	<meta name="DC.Subjetc" lang="fr" content="source scientifique marquant monde">
	<meta name="DC.Description" lang="fr" 
		content="Les sources utilisées dans le contenue du site 'Les scientifiques marquant le monde'.">
	<meta name="DC.Language" scheme="DCTERMS.RFC4646" content="fr-FR">
</head>

<body>

<nav class="menu-navi">
		
		<table>
			<tr>
				<td class="bouton"><a class="a-menu" href="index.php">Accueil</a></td>
				<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuPhy()"> Physique
					<div id ="Phy" class="test">
						<a  class='a-sousMenu' href="Hawking.php"> Stephen Hawking </a> 
						<a  class='a-sousMenu' href="Einstein.php"> Albert Einstein </a> 
						<a  class='a-sousMenu' href="Newton.php"> Isaac Newton </a> 
					</div>	
				</td>   
				<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuMaths()"> Mathématique
					<div id ="Maths" class="test">
						<a  class='a-sousMenu' href="#"> Maths1 </a> 
						<a  class='a-sousMenu' href="#"> Maths2 </a> 
						<a  class='a-sousMenu' href="#"> Maths3 </a> 
					</div>	
				</td>
				<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuBio()"> Biologie
					<div id ="Bio" class="test">
						<a  class='a-sousMenu' href="#"> Charles Darwin </a> 
						<a  class='a-sousMenu' href="#"> Bio2</a> 
						<a  class='a-sousMenu' href="#"> Bio3 </a> 
					</div>	
				</td>

				<td class="bouton"><a class="a-menu" href="Source.php"> Les Sources </a></td>
				
			

				<?php //Permet de modifier le bouton celon la connection ou non du l'utilisateur
					if(!empty($_SESSION['Prénom'])){
						echo 	'<td class="bouton">'.'<a class="a-menu" href="utilisateur.php">'.$_SESSION['Prénom']." ".$_SESSION['Nom'].' </a></td>';}
					else echo 	'<td class="bouton">'.'<a class="a-menu" href="connexion.php">'."Connexion".' </a></td>'
				?>
		
				<td class="bouton"><a class="a-menu" href="/JS/horlogetest.php"> Horloge Relative </a></td>
			</tr>
		</table>
	</nav>

<h1>Voici les sources des informations contenue sur le site.</h1>

<h2> Stephen Hawking </h2>
  <ul>
    <li><em>Hawking - L'homme, le genie et la Théorie du tout </em> Écrit par Joel Levy que je vous recommande de lire  </li>
    <li><em>Une merveilleuse histoire du temps</em> Film de 2014 réalisé par James Marsh qui est certe romancé mais loin d'être complètement faux</li>
    <li><em>Stephen Hawnking La tête dans les étoiles</em> Le documentaire d'ARTE </li>
    <li><em><a href="https://www.sciencesetavenir.fr/sciences/stephen-hawking-une-breve-histoire-d-un-genie_122003">Le Site Sciences et avenir </a></em> Résumant très rapidement la vie de Hawking</li>
  </ul>

  <p>Pour rappel ce site n'a pas pour but d'expliquer les travaux des scientifiques présentés ou de vulgariser les sciences mais tout simplement essayer donner plus d'information sur les grands noms de la Science et particulièrement de la physique </p>
  <script type="text/javascript" src="SousMenu.js"></script>

</body>

</html>