<?php //Permet de garder les variables de l'utilisateur en mémoire, autres méthode possible: cookie

session_start();
//connection a la base de donné avec test pour probleme de connexion connexion 
  try{
    $bdd = new PDO('mysql:host=localhost;dbname=bddlsmlm', 'lsmlm', 'einstein1687');}
  catch (PDOException $e)
  { print "Erreur! :".$e->getMessage()."<br/>";
    die();
  }

?>


<!DOCTYPE html>
<html>
<!-- version du 20/09/2019 -->
<head profile="http://dublincore.org/documents/2008/08/04/dc-html/">

	<title>Les scientifiques marquant le monde</title>
  <meta charset="utf-8">
	
	<link rel="stylesheet" href="stylelsmlm.css">
	
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" >
	
	<meta name="DC.Title" lang="fr" content="Les scientifiques marquant le monde">
  <!--Mots-clés -->
  <meta name="DC.Subject" lang="fr"  
    content="Stephen Hawking, Hawking, Isaac Newton, Newton, Albert Einstein, Einstein, science, scientifique, Les scientifiques marquant le monde" >
  <!--Mots-clés -->  
  <meta name="DC.Description" lang="fr"
    content="L'Histoire de certains plus grands scientifiques du monde, accessible à toutes et tous." >
  <meta name="DC.Language" scheme="DCTERMS.RFC4646" content="fr-FR" >
  
</head>

<body>

<nav class="menu-navi">
		
    <table>
      <tr>
        <td class="bouton"><a class="a-menu" href="index.php">Accueil</a></td>
       <!-- meme probleme que sur la page connexion avec la connexion.   <td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuPhy()"> Physique
          <div id ="Phy" class="test">
            <a  class='a-sousMenu' href="Hawking.php"> Stephen Hawking </a> 
            <a  class='a-sousMenu' href="Einstein.php"> Albert Einstein </a> 
            <a  class='a-sousMenu' href="Newton.php"> Isaac Newton </a> 
          </div>	
        </td>  

        <td class="bouton"><a class="a-menu" href="Source.php"> Les Sources </a></td>
        --> 
        <?php //Permet de modifier le bouton celon la connection ou non du l'utilisateur
          if(!empty($_SESSION['Prénom'])){
            echo 	'<td class="bouton">'.'<a class="a-menu" href="utilisateur.php">'.$_SESSION['Prénom']." ".$_SESSION['Nom'].' </a></td>';}
          else echo 	'<td class="bouton">'.'<a class="a-menu" href="connexion.php">'."Connexion".' </a></td>'
        ?>
        <td class="bouton"><a class="a-menu" href="/JS/horlogetest.php"> Horloge Relative </a></td>
    
        
      </tr>
    </table>
  </nav>

    <center>
    <form method="POST" action="">
        <p> Bien le bonjour <?php echo $_SESSION['Prénom'] ?> . Ici vous pouvez changer vos identifiants et m'informer que vous désirez arréter de recevoir les newletters du site, et vous deconnectez.
        <br/>
        <br/>
        <div>
            <input type="submit" name="Deconnexion" value="Je me déconnecte">
            <br/>
        </div>
      <div class = "divNL">
          <p>Voulez-vous recevoir nos newsletter? </p>  
            <input type="radio" name="NewsMail" value="oui"/> Oui
            <input type="radio" name="NewsMail" value="non"/> Non 
            <br/><br/>
            <input type="submit" name="ValidChange" value="Valider le changement">
      </div>


      <div class="divMdp">
        <p> Voulez-vous changer de mot de passe? </p>
        <table>  
          <td>Mot de passe actuel: </td> <td> <input type="password" name="mdpactuel"/> </td> </tr>  
          <td>Nouveau mot de passe : </td> <td> <input type="password" name="newmdp"/> </td> </tr> 
          <td>Confirmer nouveau mot de passe : </td> <td> <input type="password" name="newmdpconf"/> </td> </tr> 
        </table>  
        <br/>
        <input type="submit" name="ChangeMdp" value="Changer de mot de passe"> 
      </div>

      <div class="divMail">
        <p> Voulez-vous changer de mail? </p>
        <table>  
          <td>Mail actuelle: </td> <td> <input type="email" name="mailactu"/> </td> </tr>  
          <td>Nouveau mail : </td> <td> <input type="email" name="newmail"/> </td> </tr> 
          <td>Confirmer nouveau mail : </td> <td> <input type="email" name="newmailconf"/> </td> </tr> 
        </table>  
        <br/>
        <input type="submit" name="ChangeMail" value="Changer de mail"> 
      </div>
    <?php
        //DECONNEXION
        if(isset($_POST['Deconnexion'])){
            session_destroy(); //Supprime tout la session, donc deconnecte l'utilisateur
            header('Location:index.php');
        } 
        //CHANGEMENT CHOIX
        $newletterChang =($_POST['NewsMail']); 
            if(isset($_POST['ValidChange'])){ //quand on appuye sur la validation du changement
            if (!empty($_POST['NewsMail'])){  //on verifie qu'il y a bien eu un choix
                
                $Changement = $bdd->prepare("UPDATE user SET newsletter=? WHERE mail=?");
                $Changement->execute(array($newletterChang, $_SESSION['Mail'])); //fun fact -> 2heures pour me rendre compte que j'avais ecrit excute a la place d'execute donc mon code ne fonctionnais pas...
                $errorPro = "Changement effectué";
            } 
             else $errorPro = "Problème";
        }  
        //CHANGEMENT MDP réutilisation du code de connexion
        
        if(isset($_POST['ChangeMdp'])){
          $mdpactuel = sha1($_POST['mdpactuel']);
          $newmdp = sha1($_POST['newmdp']);
          $newmdpconf = sha1($_POST['newmdpconf']);
          $ReqVerifMdp = $bdd->prepare("SELECT * FROM user WHERE mail=? AND mdp= ? ");
          $ReqVerifMdp->execute(array($_SESSION['Mail'],$mdpactuel));
          $MdpValid= $ReqVerifMdp->rowCount();
          if(!empty($mdpactuel)){ 
            if($MdpValid == 1) {
              if($newmdp  == $newmdpconf  ) { //on verifie que le nouveau mot de passe et sa confirmation sont les memes
                $ChangementMdp = $bdd->prepare("UPDATE user SET mdp=? WHERE mail=?");
                $ChangementMdp->execute(array($newmdp, $_SESSION['Mail'])); 
                $errorPro = "Changement effectué.";
              }
              else $errorPro = "Les nouveaux mots de passe sont différents.";
            }
            else $errorPro = "Mauvais mot de passe.";
            } 
          else $errorPro = "Veuillez remplir mettre votre mot de passe actuel et votre nouveau mot de passe.";  
          }
        //CHANGEMENT MAIL 
        if(isset($_POST['ChangeMail'])){
          $mailactu = htmlspecialchars($_POST['mailactu']);
          $newmail = htmlspecialchars($_POST['newmail']);

          $newmailconf = htmlspecialchars($_POST['newmailconf']);
            if(!empty($mailactu) && !empty($newmail) && !empty($newmailconf)){
            if($mailactu == $_SESSION['Mail']) {
              if($newmail  == $newmailconf  ) { //on verifie que le nouveau mail et sa confirmation sont les memes
                $ChangementMail = $bdd->prepare("UPDATE user SET mail=? WHERE mail=?");
                $ChangementMail->execute(array($newmail, $_SESSION['Mail'])); 
                $errorPro = "Changement effectué.";
                $_SESSION['Mail'] = $newmail;
              }
              else $errorPro = "Les nouveaux mails sont différents.";
            }
            else $errorPro = "Mauvais mail";
           }
          else $errorPro = "Veuillez  mettre votre mail actuel et votre nouveau mail.";  
          }

        if (isset($errorPro))
        {
          echo '<p class =msgForm>'.$errorPro.'</p>';
        }
    ?>

</center>
<!--<script type="text/javascript" src="SousMenu.js"></script> -->
</body>
</html>