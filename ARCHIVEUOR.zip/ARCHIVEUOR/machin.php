<!DOCTYPE html>
<html>
<meta charset="utf-8">
<head>
<title>Test d'un formulaire</title>
</head>
<body>
<p>Ceci est une page qui soumet un formulaire (avec la méthode GET)
sur une adresse pensée pour être écoutée avec netcat. On lance la
commande netcat sur la même machine que celle où tourne le navigateur
avec <code>netcat -l 8765</code>. L'action indiquée comme attribut
de la forme est <code>http://localhost:8765/cli</code> ; elle va
conduire le navigateur à ce connecter à ce netcat.
<form method="post"
action="premier.php"
style="background-color:pink;">
<p>Ceci est le début du formulaire ; on peut y mettre
le HTML usuel.
<p>Le formulaire contient une zone où on pourra
entrer une chaine de caractères et une autre où il
faut effectuer un choix.
<p>Nom : <input type="text" name="chaine1" />
<p>Vous aimez
<input type="checkbox" name="ail">l'ail
<input type="checkbox" name="oignon">l'oignon
<input type="checkbox" name="poireau">le poireau
<input type="checkbox" name="ciboulette">la ciboulette
<p>Vous préférez
<input type="radio" name="pref" value="ail" />l'ail
<input type="radio" name="pref" value="oignon" />l'oignon
<input type="radio" name="pref" value="poireau" />le poireau
<input type="radio" name="pref" value="ciboulette" />la ciboulette
<p><input type="submit">
<p>Il y a beaucoup d'autres types d'input !
</form>
Ce texte suit le formulaire.
</body>
<html>