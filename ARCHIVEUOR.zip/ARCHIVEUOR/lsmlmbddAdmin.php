<?php //Permet de garder les variables de l'utilisateur en mémoire, autres méthode possible: cookie

session_start();
//connection a la base de donné avec test pour probleme de connexion connexion 
  try{
    $bdd = new PDO('mysql:host=localhost;dbname=bddlsmlm', 'lsmlm', 'einstein1687');}
  catch (PDOException $e)
  { print "Erreur! :".$e->getMessage()."<br/>";
    die();
  }

?>


<!DOCTYPE html>
<html>
<!-- version du 20/09/2019 -->
<head profile="http://dublincore.org/documents/2008/08/04/dc-html/">

	<title>Les scientifiques marquant le monde</title>
  <meta charset="utf-8">
	
    <link rel="stylesheet" href="stylelsmlm.css"> 
	
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" >
	
	<meta name="DC.Title" lang="fr" content="Les scientifiques marquant le monde">
  <!--Mots-clés -->
  <meta name="DC.Subject" lang="fr"  
    content="Stephen Hawking, Hawking, Isaac Newton, Newton, Albert Einstein, Einstein, science, scientifique, Les scientifiques marquant le monde" >
  <!--Mots-clés -->  
  <meta name="DC.Description" lang="fr"
    content="L'Histoire de certains plus grands scientifiques du monde, accessible à toutes et tous." >
  <meta name="DC.Language" scheme="DCTERMS.RFC4646" content="fr-FR" >
  
</head>

<body>

    <nav class="menu-navi">
		
        <table>
            <tr>
                <td class="bouton"><a class="a-menu" href="index.php">Accueil</a></td>
                <td class="bouton"><a class="a-menu" href="Hawking.php"> Stephen Hawking </a></td>
                <td class="bouton"><a class="a-menu" href="Einstein.php"> Albert Einstein </a></td>
                <td class="bouton"><a class="a-menu" href="Newton.php"> Isaac Newton </a></td>
                <td class="bouton"><a class="a-menu" href="Source.php"> Les Sources </a></td>       
            </tr>
        </table>

    </nav>
    <form method="POST" action="">
    <br/><br/><br/><br/><br/><br/>
    <table>   <!-- Mettre en tableau pour que ce soit aligné --> 
          <tr>    
            <td>Adresse Mail de l'utilisateur : </td> <td> <input type="email" name="user"/> </td>  <!-- type email detecte directement si c'est une adresse mail-->

          </tr>
          <tr>
            <td>Nouvel adresse mail de l'utilisateur: </td> <td> <input type="email" name="newMail"/> </td> 
            <td><input type="submit" name="boutonMail" value="Changement"></td>
          </tr> 
          <tr>
            <td>Nouveau mot de passe de l'utilisateur: </td> <td> <input type="password" name="newMdp"/> </td> 
            <td><input type="submit" name="boutonMdp" value="Changement"></td>
          </tr>    
       </table>
       <br/><br/>


       <br/><br/>
    <?php 
     
       $user = htmlspecialchars($_POST['user']);
       $newMail = htmlspecialchars($_POST['newMail']);
       $newMdp = sha1($_POST['newMdp']);
       //Changement de mail
       if (isset ($_POST['boutonMail'])){
           if (!empty ($user)){
               $reqChangemail = $bdd->prepare("UPDATE user SET mail=? WHERE mail=?");
               $reqChangemail->execute(array($newMail,$user));
               $information = "Changement de mail effectué";
            }
        }
       //Changement de mdp
       if (isset ($_POST['boutonMdp'])){
        if (!empty($user)){
            $reqChangemail = $bdd->prepare("UPDATE user SET mdp=? WHERE mail=?");
            $reqChangemail->execute(array($newMdp,$user));
            $information = "Changement de mot de passe effectué";
        }
       }

       if (isset ($information)){
         echo '<font color="red" size=5>'.$information.'</font>'.'<br/>'.'<br/>';
       }

       if (isset ($_POST['lirebdd'])){
        //Ecrire le css directement dans la page html avec php sinon css ne s'applique pas...
            echo '<input type="submit" name="lirebdd" value="Actualiser les données affichées">' ;//affiche bouton actualisation
            echo '<center><table class= "tablebdd">';
            echo '<style>.tablebdd {border-collapse: collapse;width: 50%;}.tablebdd,.bdd{border: 1px solid black;}</style>';
            echo '<tr><th class=bdd>Nom</th><th class=bdd>Prénom</th><th class=bdd> Mail</th><th class=bdd>Newsletter</th></tr>';
        $Reqafficher = $bdd->prepare("SELECT * FROM user");
        $Reqafficher->execute();
        while ($Afficher = $Reqafficher->fetch()){
            echo "<tr class=bdd>"."<td class=bdd>".$Afficher['nom']."</td>"."<td class=bdd>".$Afficher['prenom']."</td>"."<td class=bdd>".$Afficher['mail']."</td>"."<td class=bdd>".$Afficher['newsletter']."</td>"."</tr>";
        }
            echo "</table>";
            $actualiser = 1; //on créer la variable actualiser que lorsqu'on a deja appuyer sur afficher la base de donnée
        }

        
        if (empty ($actualiser)){ //affiche le bouton pour afficher la base de données,seulement si actualiser est vide/n'existe pas
            echo'<input type="submit" name="lirebdd" value="Afficher base de données"></center>';
            }
         
    ?>


</body>
</html>