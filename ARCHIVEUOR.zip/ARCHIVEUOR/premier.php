
<!DOCTYPE html>
<html>
<head>
<title>Exemple de réception d'un formulaire</title>
<meta charset="utf-8">
</head>
<body>
<strong><large><center>Réception</center></large></strong>
<p>C'est ici qu'arrivent les données du formulaire.
<?php
$nom = $_POST['chaine1'];
$nom != NULL || $nom = 'Jean-Personne';
# Une façon de compter les choses cochées
$compte = 0;
for($i = 0; $i < count($liste); $i++)
if ($_POST[$liste[$i]] == "on")
$compte += 1;
echo "<p>Bonjour, $nom";
echo "<p>Compte vaut " . $compte . ".";
if ($compte == count($liste))
echo "<p>Vous aimez tout !";
else if ($compte == 0)
echo "<p>Vous êtes vraiment difficile !";
else
echo "<p>Rien à dire.";
?>
<p>Fin des données du formulaire PHP.
</body>
<html>