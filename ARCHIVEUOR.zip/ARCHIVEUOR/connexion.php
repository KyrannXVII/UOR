<?php //Permet de garder les variables de l'utilisateur en mémoire, autres méthode possible: cookie
session_start();
?>


<!DOCTYPE html>
<html>
<!-- version du 20/09/2019 -->
<head profile="http://dublincore.org/documents/2008/08/04/dc-html/">

	<title>Les scientifiques marquant le monde</title>
  <meta charset="utf-8">
	
	<link rel="stylesheet" type="text/css" href="stylelsmlm.css"> 
	
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" >
	
	<meta name="DC.Title" lang="fr" content="Les scientifiques marquant le monde">
  <!--Mots-clés -->
  <meta name="DC.Subject" lang="fr"  
    content="Stephen Hawking, Hawking, Isaac Newton, Newton, Albert Einstein, Einstein, science, scientifique, Les scientifiques marquant le monde" >
  <!--Mots-clés -->  
  <meta name="DC.Description" lang="fr"
    content="L'Histoire de certains plus grands scientifiques du monde, accessible à toutes et tous." >
  <meta name="DC.Language" scheme="DCTERMS.RFC4646" content="fr-FR" >
  

</head>

<body>

    <nav class="menu-navi">
		
        <table>
            <tr>
                <td class="bouton"><a class="a-menu" href="index.php">Accueil</a></td>
            <!--    <td class="bouton"><a class="a-menu" href="Hawking.php"> Stephen Hawking </a></td>
                <td class="bouton"><a class="a-menu" href="Einstein.php"> Albert Einstein </a></td>
                <td class="bouton"><a class="a-menu" href="Newton.php"> Isaac Newton </a></td>
                <td class="bouton"><a class="a-menu" href="Source.php"> Les Sources </a></td> > -->
          
                <td class="bouton"><a class="a-menu" href="connexion.php"> Connexion </a></td>
                <td class="bouton"><a class="a-menu" href="/JS/horlogetest.php"> Horloge Relative </a></td>
                
            </tr>
        </table>
    </nav>
<center>

    <form method="POST"
          action=""
          class="form">
<!-- HTML INSCRIPTION -->          
 <div class="Inscription">     
      <h1> Inscription </h1>
            <table>   <!-- Mettre en tableau pour que ce soit aligné --> 
              <tr>
                <td>Nom :</td> <td><input type="text" name="chaine1" value="<?php if(isset($nom)) { echo $nom; } ?>"/> </td> </tr>  
              <tr> 
                <td>Prénom :</td> <td><input type="text" name="chaine2" value="<?php if(isset($prenom)) { echo $prenom; } ?>"/> </td> </tr>  
              <tr>  
                <td>Adresse Mail : </td> <td> <input type="email" name="chaine3"/> </td> </tr>  <!-- type email detecte directement si c'est une adresse mail-->
              <tr>
              <tr>  
                <td>Comfirmé Adresse Mail : </td> <td> <input type="email" name="chaine3-5"/> </td> </tr>  <!-- type email detecte directement si c'est une adresse mail-->
              <tr>
                <td>Mot de passe : </td> <td> <input type="password" name="chaine4"/> </td> </tr>  
              </table>
            <p> Voulez-vous recevoir nos newsletters? </p>
            <input type="radio" name="recevoirMail" value="oui"/> Oui
            <input type="radio" name="recevoirMail" value="non"/> Non 
            <br/><br/>
            <input type="submit" name="boutonInscri" value="Je m'inscris">
 </div>

<!--PHP INSCRIPTION -->    
  
  <?php //connection a la base de donné avec test pour probleme de connexion connexion 
    try{
      $bdd = new PDO('mysql:host=localhost;dbname=bddlsmlm', 'lsmlm', 'einstein1687');}
    catch (PDOException $e)
    { print "Erreur! :".$e->getMessage()."<br/>";
      die();
    }
  //Série de test pour verifié que les toutes les informations ont été donné et sont correctes

      //quand on appuye sur le bouton:
    if (isset($_POST['boutonInscri'])){
      //on test si tout les données demandés ont été rempli,cad check que leur varible non sont pas vide
      if (!empty($_POST['chaine1']) && !empty($_POST['chaine2']) && !empty($_POST['chaine3']) && !empty($_POST['chaine3-5']) && !empty($_POST['chaine4']))
        {                              
          $nom       = htmlspecialchars($_POST['chaine1']);
          $prenom    = htmlspecialchars($_POST['chaine2']);
          $mail      = htmlspecialchars($_POST['chaine3']);
          $mail2     = htmlspecialchars($_POST['chaine3-5']);
          $newletter = htmlspecialchars($_POST['recevoirMail']);
          $mdp       = sha1($_POST['chaine4'] );
          //Verifie que le choix est fait 
          if (!empty($_POST['recevoirMail'])){
            //Vérifie que les deux adresses mails correspondent
            if($mail == $mail2)
              {
                //Evite d'utiliser un mail déjà présent dans le bdd
                $maildansbdd = $bdd->prepare("SELECT * FROM user WHERE mail = ?"); //on demande les lignes ou le mail est present dans la table
                $maildansbdd->execute(array($mail));
                $nbr = $maildansbdd->rowCount();                               //et ensuite on compte le nombre de ligne qu'il y a
                if($nbr == 0) {                                                // si y en a 0 = il n'y a pas de ligne avec le mail dans la table donc le mail n'a jamais été utilisé
                  $enregistrer = $bdd->prepare("INSERT INTO user(nom, prenom, mail, mdp,newsletter) VALUES(?, ?, ?, ?,?)");
                  $enregistrer->execute(array($nom,$prenom, $mail, $mdp,$newletter));
                  $error = "Votre compte est créé !";                          //ce n'est pas une erreur cela evite juste de devoir rajouter des ligne pour informer que le compte est crée
                  //aprés inscription, se connecte directement
                  $_SESSION['Prénom'] = $prenom;
                  $_SESSION['Nom']    = $nom;
                  $_SESSION['Mail']   = $mail;
                  header('Location:index.php');  
                }
                else                                                       //sinon y en a 1 (au maximum de ce fait) et donc le mail est deja utilisé
                  $error = "Mail déjà utilisé";                
              }
            else 
              $error = "Les adresses mails ne sont pas les mêmes.";
            }
          else $error= "N'oubliez pas de cocher votre choix";
      }
    else 
      $error = "Veuillez remplir tout le formulaire s'il vous plaît.";
    }
    
  //  if (isset($error))
   // {
     // echo '<br/>'.'<font color="red" size=5>'.$error.'</font>';
    //}
  ?>
<!-- HTML CONNEXION -->
  <div class="Connexion">
      <h1> Connexion </h1>
        <table>   <!-- Mettre en tableau pour que ce soit aligné --> 
            <tr>    
              <td>Adresse Mail : </td> <td> <input type="email" name="identifiant"/> </td>  <!-- type email detecte directement si c'est une adresse mail-->
            </tr>
            <tr>
              <td>Mot de passe : </td> <td> <input type="password" name="mdp"/> </td> 
            </tr>  
        </table>
        <br/><br/>
        <input type="submit" name=boutonConnexion value="Je me connecte">
  </div>
<!-- PHP CONNEXION -->
  <?php
    try{
      $bdd = new PDO('mysql:host=localhost;dbname=bddlsmlm', 'lsmlm', 'einstein1687');}
    catch (PDOException $e)
    { print "Erreur! :".$e->getMessage()."<br/>";
      die();
    }
    if(isset($_POST['boutonConnexion'])){
      $identifiant      = htmlspecialchars($_POST['identifiant']);
      $mdpCo            = sha1($_POST['mdp']);
      if(!empty($identifiant) && !empty($mdpCo)){
        $reqIdentifiant_co = $bdd->prepare("SELECT * FROM user WHERE mail=? AND mdp= ? ");
        $reqIdentifiant_co->execute(array($identifiant,$mdpCo));
        $Identidiant_co = $reqIdentifiant_co->rowCount(); //verifie que les identifiant sont ok, si la recherche renvoie une ligne c'est qye c'bon sinon c'faux(l'inverse de l'inscription)
        if ($Identidiant_co == 1){
          //Permet de faire qu'une requete a la base de donnée, sinon on aurait pu aussi faire une requete pour chaque données que l'on voulait
            $comptereq = $bdd->prepare("SELECT * FROM user WHERE mail=? ");
            $comptereq->execute(array($identifiant));
            $compte = $comptereq->fetch();
            $_SESSION['Prénom'] = $compte['prenom'];
            $_SESSION['Nom']    = $compte['nom'];
            $_SESSION['Mail']   = $compte['mail'];
            header('Location:index.php'); //permet de retourner sur la page de l'index
        }
        else $error="Problème d'adresse, ou de mot de passe";
      }
      else $error ="Rentre tes identifiants quand même.";
    }
    
   
  ?>
<?php 
  if (isset($error))
    {
      echo '<p class =msgForm>'.$error.'</p>';
    }
?>
</center>


</body>

</html>