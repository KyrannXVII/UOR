<?php //Permet de garder les variables de l'utilisateur en mémoire, autres méthode possible: cookie

session_start();

?>

<!DOCTYPE html>
<html>

<head profile="http://dublincore.org/documents/2008/08/04/dc-html/">

	<title>Les scientifiques marquant le monde</title>
  <meta charset="utf-8">
	
	<link rel="stylesheet" href="Chatbot.css">
	
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" >
	
	<meta name="DC.Title" lang="fr" content="Les scientifiques marquant le monde">
  <!--Mots-clés -->
  <meta name="DC.Subject" lang="fr"  
    content="Stephen Hawking, Hawking, Isaac Newton, Newton, Albert Einstein, Einstein, science, scientifique, Les scientifiques marquant le monde" >
  <!--Mots-clés -->  
  <meta name="DC.Description" lang="fr"
    content="L'Histoire de certains plus grands scientifiques du monde, accessible à toutes et tous." >
  <meta name="DC.Language" scheme="DCTERMS.RFC4646" content="fr-FR" >

</head>

<body>

		<nav class="menu-navi">
		
				<table>
					<tr>
						<td class="bouton"><a class="a-menu" href="index.php">Accueil</a></td>
						<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuPhy()"> Physique </a> 
							<div id ="Phy" class="test">
								<a  class='a-sousMenu' href="Hawking.php"> Stephen Hawking </a> 
								<a  class='a-sousMenu' href="Einstein.php"> Albert Einstein </a> 
								<a  class='a-sousMenu' href="Newton.php"> Isaac Newton </a> 
							</div>	
						</td>   
						<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuMaths()"> Mathématique </a> 
							<div id ="Maths" class="test">
								<a  class='a-sousMenu' href="#"> Maths1 </a> 
								<a  class='a-sousMenu' href="#"> Maths2 </a> 
								<a  class='a-sousMenu' href="#"> Maths3 </a> 
							</div>	
						</td>
						<td class="bouton"> <a class="a-menu" href="#" onclick="SousMenuBio()"> Biologie </a> 
							<div id ="Bio" class="test">
								<a  class='a-sousMenu' href="#"> Charles Darwin </a> 
								<a  class='a-sousMenu' href="#"> Bio2</a> 
								<a  class='a-sousMenu' href="#"> Bio3 </a> 
							</div>	
						</td>

						<td class="bouton"><a class="a-menu" href="Source.php"> Les Sources </a></td>
						
					

						<?php //Permet de modifier le bouton celon la connection ou non du l'utilisateur
							if(!empty($_SESSION['Prénom'])){
								echo 	'<td class="bouton">'.'<a class="a-menu" href="utilisateur.php">'.$_SESSION['Prénom']." ".$_SESSION['Nom'].' </a></td>';}
							else echo 	'<td class="bouton">'.'<a class="a-menu" href="connexion.php">'."Connexion".' </a></td>'
						?>
						
						 <td class="bouton"><a class="a-menu" href="/JS/horlogetest.php"> Horloge Relative </a></td>
						
					</tr>
				</table>
			</nav>
			
    <h1>Les scientifiques qui ont marqué le monde</h1>
	<p>

		Dans le cadre du cours "Utilisation d'ordinateurs en réseau"
		de ma Licence d'informatique à l'IED Paris 8 j'ai eu comme devoir de développer une page Web personnelle.<br />
		Cependant n'ayant pas l'envie de produire une page web CV (Par manque de contenu) je me suis plongé dans l'une de mes
		passion, la physique et de ce fait pour que ma page web reste attractif au plus grand nombre je n'allais pas relater
		des conceptes complexes de la physique pouvant être hermétique au grand nombre.
	</p>

	<p>
		Donc j'ai décidé de parler de ces scientifiques
		qui ont changé le monde. Il y en a des centaines, plus ou moins connu c'est pour cela que je ne parlerais que de ceux
    que l'on connais sans même être interessé par la physique. 
    Et pour cela j'ai commencé par le grand Stephen Hawking, le reste du contenue viendras au fur et a mesure du temps.
	</p>
    <h2 style="text-align:center">Stephen Hawking</h2>
    <p style="text-align:center"><a href="Hawking.php"> <img src="Images/Hawking.jpg" alt="Portrait de Stephen Hawking" width="384" height="272"> </a></p>

    <h2 style="text-align:center">Albert Einstein</h2>
    <p style="text-align:center"><a href="Einstein.php"> <img src="Images/Einstein.jpg" alt="Portrait de Stephen Hawking" width="384" height="372"> </a></p>

    <h2 style="text-align:center">Isaac Newton</h2>
    <p style="text-align:center"><a href="Newton.php"> <img src="Images/Newton.jpg" alt="Portrait de Stephen Hawking" width="384" height="292"> </a></p>
	



	<!-- Relie le fichier JavaScript au code source de la page -->
	<script type="text/javascript" src="SousMenu.js"></script> 


<div id ="chatbot" class="testb">
	<a class="a-chatbot" href="#" onclick="Chatbotcacher()"> <img src="Images/istockphoto-873945226-612x612.jpg" width="60" height="80" > </a> 
	<div id="Bot" class ="contourfenetrebot">
		<div id="Botblabla" class="fenetrechatbot"> </div>
		<input type="text" name = "barrediscu" class ="blabla" id = "in" maxlength="160" > <!-- 160 caractere comme pour un sms ca suffit--> 
		<button type="button" onclick="getValue()" id="BE" class="bla">Enter</button>
	</div>
</div>

<script type="text/javascript" src="Chatbot.js"></script> 
</body>

</html>